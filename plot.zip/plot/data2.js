
  var students= [
  {studentId: 1, mathScore: 72, scienceScore: 88},
  {studentId: 2, mathScore: 85, scienceScore: 92},
  {studentId: 3, mathScore: 78, scienceScore: 72},
  {studentId: 4, mathScore: 91, scienceScore: 90},
  {studentId: 5, mathScore: 66, scienceScore: 75},
  {studentId: 6, mathScore: 77, scienceScore: 85},
  {studentId: 7, mathScore: 92, scienceScore: 98},
  {studentId: 8, mathScore: 83, scienceScore: 82},
  {studentId: 9, mathScore: 79, scienceScore: 76},
  {studentId: 10, mathScore: 87, scienceScore: 94}
]
